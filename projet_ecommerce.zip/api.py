
from database import DBManager

class PaymentAPI:
    """API publique pour gérer les transactions."""
    def __init__(self):
        self.db = DBManager()
        
    def process_checkout(self, user_email, product_id):
        """Point d'entrée principal pour valider un panier."""
        user = self.db.get_user(user_email)
        self.db.save_order(user, product_id)
        self.send_email_confirmation(user)
        
    def send_email_confirmation(self, user):
        """Envoie un mail de confirmation à l'utilisateur."""
        pass
