
import models

class DBManager:
    """Gère les accès à la base de données."""
    def get_user(self, email):
        return models.User("John Doe", email)
    
    def save_order(self, user, product):
        """Sauvegarde la commande en base de données."""
        pass
