
class User:
    """Représente un utilisateur du système e-commerce."""
    def __init__(self, name, email):
        self.name = name
        self.email = email

class Product:
    """Représente un produit achetable."""
    def __init__(self, id, price):
        self.id = id
        self.price = price
